﻿using System;
using System.IO;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Xml.Serialization;
using WeatherForeCast.Interface;

namespace WeatherForeCast.Service
{
    public class Weather : IWeather
    {
        /// <summary>
        /// Purpose: To Call weather API
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="ReqUrl"></param>
        /// <returns></returns>
        public T Request<T>(string ReqUrl)
        {
            try
            {
                using (var client = new HttpClient())
                {
                    client.BaseAddress = new Uri(ReqUrl);
                    client.DefaultRequestHeaders.Accept.Clear();
                    client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/xml"));

                    HttpResponseMessage response = client.GetAsync(ReqUrl).Result;
                    if (response.IsSuccessStatusCode)
                    {
                        XmlSerializer serializer = new XmlSerializer(typeof(T));
                        T result;

                        // convert string to stream
                        byte[] byteArray = Encoding.ASCII.GetBytes(response.Content.ReadAsStringAsync().Result);

                        MemoryStream stream = new MemoryStream(byteArray);

                        using (StreamReader reader = new StreamReader(stream))
                        {
                            result = (T)serializer.Deserialize(reader);
                        }

                        return result;
                    }
                    else
                    {
                        return default(T);
                    }
                }
            }
            catch (Exception)
            {
                throw;
            }
        }

    }
}
