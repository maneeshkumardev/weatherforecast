﻿using System.Configuration;

namespace WeatherForeCast.Common
{
    public static class Config
    {
        public static string WeatherApiKey { get { return ConfigurationManager.AppSettings["WeatherApiKey"]; } }
        public static string WeatherURL { get { return ConfigurationManager.AppSettings["WeatherURL"]; } }
        public static string WeatherCity { get { return ConfigurationManager.AppSettings["WeatherCity"]; } }
        public static string WeatherAPIResponseMode { get { return ConfigurationManager.AppSettings["WeatherAPIResponseMode"]; } }
    }
}