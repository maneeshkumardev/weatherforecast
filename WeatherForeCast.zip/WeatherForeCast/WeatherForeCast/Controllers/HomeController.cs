﻿using System.Web.Mvc;
using WeatherForeCast.Common;
using WeatherForeCast.Interface;
using WeatherForeCast.Models;

namespace WeatherForeCast.Controllers
{
    public class HomeController : Controller
    {
        private readonly IWeather _weather;

        public HomeController(IWeather weather)
        {
            this._weather = weather;
        }
        /// <summary>
        /// Purpose: This method is used to display weather information
        /// </summary>
        /// <returns></returns>
        public ActionResult Index()
        {
            ///I have fetched key detail from config file but we can also get these information from database.
            var apiRequest = Config.WeatherURL + "?q=" + Config.WeatherCity + "&appid=" + Config.WeatherApiKey + "&mode=" + Config.WeatherAPIResponseMode;

            var weatherAPIResponse = _weather.Request<Weatherdata>(apiRequest);

            return View("Index", weatherAPIResponse);
        }
    }
}