﻿namespace WeatherForeCast.Interface
{
    public interface IWeather
    {
        T Request<T>(string ReqUrl);
    }
}
