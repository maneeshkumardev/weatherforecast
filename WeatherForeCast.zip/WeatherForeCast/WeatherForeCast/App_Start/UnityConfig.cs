using System.Web.Mvc;
using Unity;
using Unity.Mvc5;
using WeatherForeCast.Interface;
using WeatherForeCast.Service;

namespace WeatherForeCast
{
    public static class UnityConfig
    {
        public static void RegisterComponents()
        {
			var container = new UnityContainer();

            container.RegisterType<IWeather, Weather>();

            DependencyResolver.SetResolver(new UnityDependencyResolver(container));
        }
    }
}